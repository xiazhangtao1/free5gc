// Copyright 2019-2023 go-pfcp authors. All rights reserved.
// Use of this source code is governed by a MIT-style license that can be
// found in the LICENSE file.

package ie

import (
	"time"
)

// NewTimeOfFirstPacket creates a new TimeOfFirstPacket IE.
func NewTimeOfFirstPacket(ts time.Time) *IE {
	u64sec := uint64(ts.Sub(time.Date(1900, time.January, 1, 0, 0, 0, 0, time.UTC))) / 1000000000
	return newUint32ValIE(TimeOfFirstPacket, uint32(u64sec))
}

// TimeOfFirstPacket returns TimeOfFirstPacket in time.Time if the type of IE matches.
func (i *IE) TimeOfFirstPacket() (time.Time, error) {
	switch i.Type {
	case TimeOfFirstPacket:
		return i.valueAs3GPPTimestamp()
	case UsageReportWithinSessionModificationResponse,
		UsageReportWithinSessionDeletionResponse,
		UsageReportWithinSessionReportRequest:
		ies, err := i.UsageReport()
		if err != nil {
			return time.Time{}, err
		}
		for _, x := range ies {
			if x.Type == TimeOfFirstPacket {
				return x.TimeOfFirstPacket()
			}
		}
		return time.Time{}, ErrIENotFound
	default:
		return time.Time{}, &InvalidTypeError{Type: i.Type}
	}
}
