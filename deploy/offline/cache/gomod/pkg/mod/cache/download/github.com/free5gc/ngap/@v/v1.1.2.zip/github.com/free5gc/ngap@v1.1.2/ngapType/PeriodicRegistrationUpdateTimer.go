package ngapType

import "github.com/free5gc/aper"

// Need to import "github.com/free5gc/aper" if it uses "aper"

type PeriodicRegistrationUpdateTimer struct {
	Value aper.BitString `aper:"sizeLB:8,sizeUB:8"`
}
