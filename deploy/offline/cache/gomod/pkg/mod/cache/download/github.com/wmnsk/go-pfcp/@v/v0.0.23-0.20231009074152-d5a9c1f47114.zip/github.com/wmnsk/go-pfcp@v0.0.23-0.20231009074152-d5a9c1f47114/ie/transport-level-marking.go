// Copyright 2019-2023 go-pfcp authors. All rights reserved.
// Use of this source code is governed by a MIT-style license that can be
// found in the LICENSE file.

package ie

// NewTransportLevelMarking creates a new TransportLevelMarking IE.
func NewTransportLevelMarking(tos uint16) *IE {
	return newUint16ValIE(TransportLevelMarking, tos)
}

// TransportLevelMarking returns TransportLevelMarking in uint16 if the type of IE matches.
func (i *IE) TransportLevelMarking() (uint16, error) {
	switch i.Type {
	case TransportLevelMarking:
		return i.ValueAsUint16()
	case ForwardingParameters:
		ies, err := i.ForwardingParameters()
		if err != nil {
			return 0, err
		}
		for _, x := range ies {
			if x.Type == TransportLevelMarking {
				return x.TransportLevelMarking()
			}
		}
		return 0, ErrIENotFound
	case UpdateForwardingParameters:
		ies, err := i.UpdateForwardingParameters()
		if err != nil {
			return 0, err
		}
		for _, x := range ies {
			if x.Type == TransportLevelMarking {
				return x.TransportLevelMarking()
			}
		}
		return 0, ErrIENotFound
	case DuplicatingParameters:
		ies, err := i.DuplicatingParameters()
		if err != nil {
			return 0, err
		}
		for _, x := range ies {
			if x.Type == TransportLevelMarking {
				return x.TransportLevelMarking()
			}
		}
		return 0, ErrIENotFound
	case UpdateDuplicatingParameters:
		ies, err := i.UpdateDuplicatingParameters()
		if err != nil {
			return 0, err
		}
		for _, x := range ies {
			if x.Type == TransportLevelMarking {
				return x.TransportLevelMarking()
			}
		}
		return 0, ErrIENotFound
	case GTPUPathQoSControlInformation:
		ies, err := i.GTPUPathQoSControlInformation()
		if err != nil {
			return 0, err
		}
		for _, x := range ies {
			if x.Type == TransportLevelMarking {
				return x.TransportLevelMarking()
			}
		}
		return 0, ErrIENotFound
	case GTPUPathQoSReport:
		ies, err := i.GTPUPathQoSReport()
		if err != nil {
			return 0, err
		}
		for _, x := range ies {
			if x.Type == TransportLevelMarking {
				return x.TransportLevelMarking()
			}
		}
		return 0, ErrIENotFound
	case QoSInformationInGTPUPathQoSReport:
		ies, err := i.QoSInformationInGTPUPathQoSReport()
		if err != nil {
			return 0, err
		}
		for _, x := range ies {
			if x.Type == TransportLevelMarking {
				return x.TransportLevelMarking()
			}
		}
		return 0, ErrIENotFound
	default:
		return 0, &InvalidTypeError{Type: i.Type}
	}

}
